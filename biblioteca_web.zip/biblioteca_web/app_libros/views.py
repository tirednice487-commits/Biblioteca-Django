from django.shortcuts import render

def lista(request):
    libros = [
        {"isbn": "978-0307474728", "titulo": "Cien años de soledad", "descripcion": "Saga de la familia Buendía en Macondo.", "categoria": "Novela"},
        {"isbn": "978-0142437230", "titulo": "Don Quijote de la Mancha", "descripcion": "Las aventuras de un hidalgo y su escudero.", "categoria": "Clásico"},
        {"isbn": "978-0060883287", "titulo": "Pedro Páramo", "descripcion": "Un hijo busca a su padre en Comala.", "categoria": "Novela"},
        {"isbn": "978-0156012195", "titulo": "El principito", "descripcion": "Un niño viajero explora diversos planetas.", "categoria": "Infantil"},
        {"isbn": "978-0451524935", "titulo": "1984", "descripcion": "Distopía sobre un estado totalitario.", "categoria": "Ciencia ficción"},
        {"isbn": "978-0743273565", "titulo": "El gran Gatsby", "descripcion": "Ambición y desencanto en los años veinte.", "categoria": "Novela"},
        {"isbn": "978-0061120084", "titulo": "Matar a un ruiseñor", "descripcion": "Justicia y prejuicio en el sur de EE. UU.", "categoria": "Drama"},
        {"isbn": "978-0307277671", "titulo": "La sombra del viento", "descripcion": "Misterio entre libros en Barcelona.", "categoria": "Misterio"},
        {"isbn": "978-0525559474", "titulo": "Python para todos", "descripcion": "Introducción a la programación en Python.", "categoria": "Tecnología"},
        {"isbn": "978-0132350884", "titulo": "Código limpio", "descripcion": "Buenas prácticas para escribir software.", "categoria": "Tecnología"},
    ]
    return render(request, 'libros.html', {"libros": libros})