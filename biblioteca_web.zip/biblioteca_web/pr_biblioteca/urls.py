from django.contrib import admin
from django.shortcuts import render
from django.urls import path, include

def inicio(request):
    return render(request, 'inicio.html')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', inicio),
    path('usuarios/', include('app_usuarios.urls')),
    path('libros/', include('app_libros.urls')),
]
